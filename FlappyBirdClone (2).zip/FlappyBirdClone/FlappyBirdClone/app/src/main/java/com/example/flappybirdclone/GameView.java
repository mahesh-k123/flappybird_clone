package com.example.flappybirdclone;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.Random;

public class GameView extends SurfaceView implements SurfaceHolder.Callback, update {
    private GameThread gameThread;
    private ArrayList<Pipe> pipes;
    private Random random;
    private Bitmap birdBitmap;
    private int birdX = 200;
    private float birdY;
    private float birdVelocity;
    private final float gravity = 2.0f;
    private final float jumpVelocity = -30f;

    private int screenWidth, screenHeight;
    private int pipeGap = 400;
    private int pipeWidth = 200;
    private int pipeSpeed = 15;
    private int score = 0;

    private boolean isGameOver = false;

    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);
        gameThread = new GameThread(getHolder(), this);
        pipes = new ArrayList<>();
        random = new Random();
        birdBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.bird); // Replace with actual bird sprite
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        screenWidth = getWidth();
        screenHeight = getHeight();
        resetGame();
        gameThread.setRunning(true);
        gameThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }


    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry = true;
        while (retry) {
            try {
                gameThread.setRunning(false);
                gameThread.join();
                retry = false;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (isGameOver) {
                resetGame();
            } else {
                birdVelocity = jumpVelocity;
            }
        }
        return true;
    }

    @Override
    public void update() {
        if (!isGameOver) {
            birdVelocity += gravity;
            birdY += birdVelocity;

            if (birdY + birdBitmap.getHeight() > screenHeight || birdY < 0) {
                isGameOver = true;
            }

            updatePipes();

            for (Pipe pipe : pipes) {
                if (pipe.collidesWith(birdX, (int) birdY, birdBitmap.getWidth(), birdBitmap.getHeight())) {
                    isGameOver = true;
                    break;
                }
            }
        }
    }

    private void updatePipes() {
        for (Pipe pipe : pipes) {
            pipe.update(pipeSpeed);

            if (pipe.getX() + pipeWidth < 0) {
                pipe.reset(screenWidth+3000, random.nextInt(screenHeight - pipeGap-100 ) + 200);
                score++;
            }
        }
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            canvas.drawColor(Color.CYAN);

            canvas.drawBitmap(birdBitmap, birdX, birdY, null);

            Paint pipePaint = new Paint();
            pipePaint.setColor(Color.GREEN);
            for (Pipe pipe : pipes) {
                pipe.draw(canvas, pipePaint);
            }

            Paint scorePaint = new Paint();
            scorePaint.setColor(Color.BLACK);
            scorePaint.setTextSize(100);
            canvas.drawText("Score: " + score, 50, 150, scorePaint);

            if (isGameOver) {
                Paint gameOverPaint = new Paint();
                gameOverPaint.setColor(Color.RED);
                gameOverPaint.setTextSize(120);
                canvas.drawText("GAME OVER", screenWidth / 2f - 300, screenHeight / 2f, gameOverPaint);

                Paint restartPaint = new Paint();
                restartPaint.setColor(Color.BLACK);
                restartPaint.setTextSize(80);
                canvas.drawText("Tap to Restart", screenWidth / 2f - 200, screenHeight / 2f + 100, restartPaint);
            }
        }
    }

    private void resetGame() {
        birdY = screenHeight / 2f;
        birdVelocity = 0;
        score = 0;
        isGameOver = false;
        initializePipes();
    }

    private void initializePipes() {
        pipes.clear();
        for (int i = 0; i < 10; i++) {
            int pipeX = screenWidth + i * 1000;
            int pipeY = random.nextInt(screenHeight - pipeGap-200 ) + 100; // Random Y position
            pipes.add(new Pipe(pipeX-100, pipeY, pipeWidth, pipeGap));
        }
    }


}
