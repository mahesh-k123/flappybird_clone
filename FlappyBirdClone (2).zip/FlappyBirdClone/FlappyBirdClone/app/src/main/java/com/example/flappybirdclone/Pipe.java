package com.example.flappybirdclone;

//import static androidx.appcompat.graphics.drawable.DrawableContainerCompat.Api21Impl.getResources;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import com.example.flappybirdclone.R;



import android.graphics.Canvas;
import android.graphics.Paint;

public class Pipe {
    private int x;
    private int y;
    private int width;
    private int gap;
    private boolean scored;

    public Pipe(int x, int y, int width, int gap) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.gap = gap;
        this.scored = false;
    }

    public void update(int speed) {
        x -= speed;
    }

    public void reset(int screenWidth, int newY) {
        x = screenWidth;
        y = newY;
        scored = false;
    }

    public boolean collidesWith(int birdX, int birdY, int birdWidth, int birdHeight) {
        boolean collidesBottom = birdX + birdWidth > x && birdX < x + width &&
                birdY + birdHeight > y + gap;

        boolean collidesTop = birdX + birdWidth > x && birdX < x + width &&
                birdY < y;

        return collidesTop || collidesBottom;
    }

    public void draw(Canvas canvas, Paint paint) {
        canvas.drawRect(x, 0, x + width, y, paint);

        canvas.drawRect(x, y + gap, x + width, canvas.getHeight(), paint);
    }

    public int getX() {
        return x;
    }

    public boolean isScored() {
        return scored;
    }

    public void setScored(boolean scored) {
        this.scored = scored;
    }
}

