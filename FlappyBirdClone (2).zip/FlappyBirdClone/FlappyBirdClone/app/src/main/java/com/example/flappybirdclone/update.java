package com.example.flappybirdclone;

public interface update {
    void update();
}
